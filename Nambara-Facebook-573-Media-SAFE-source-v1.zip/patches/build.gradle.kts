group = "pt.nambara"

patches {
    // TODO: Update this section with your project details.
    about {
        name = "Nambara Facebook Patches"
        description = "Experimental SAFE media patch for Facebook 573.0.0.37.74"
        source = "https://github.com/nambara4-debug/Nambara"
        author = "Nambara"
        contact = "https://github.com/nambara4-debug"
        website = "https://github.com/nambara4-debug/Nambara"
        license = "GPLv3"
    }
}

// Separate configuration so gson is available at runtime for the
// generatePatchesList task but never bundled into the APK.
val patchListGeneratorClasspath = configurations.create("patchListGeneratorClasspath")

dependencies {
    compileOnly(libs.gson)
    patchListGeneratorClasspath(libs.gson)
}

tasks {
    register<JavaExec>("generatePatchesList") {
        description = "Build patch with patch list"

        dependsOn(build)

        classpath = sourceSets["main"].runtimeClasspath + patchListGeneratorClasspath
        mainClass.set("util.PatchListGeneratorKt")
    }

    // Used by gradle-semantic-release-plugin.
    publish {
        dependsOn("generatePatchesList")
    }
}

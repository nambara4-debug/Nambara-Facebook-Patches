# Nambara FB Media SAFE 573

Variante experimental do patch de descarregamento de média para o Facebook
`573.0.0.37.74`.

## Alteração de segurança

Os *hooks* directos dos cabeçalhos de Stories (`LX/9Uw`, `LX/P0G` e `LX/9W5`)
ficam desactivados. Esses *hooks* são o principal suspeito dos encerramentos ao
abrir média. O suporte de descarregamento de vídeos normais e Reels permanece
activo.

Consequência prevista: o botão de descarregamento pode não aparecer nas Stories.

## Compilar no GitHub

1. Carregar o conteúdo desta pasta para o repositório.
2. Abrir **Actions**.
3. Escolher **Compilar Nambara FB Media SAFE**.
4. Carregar em **Run workflow**.
5. Quando terminar, descarregar o artefacto
   **Nambara-Facebook-573-Media-SAFE**, ou usar o ficheiro publicado em
   **Releases**.

## Teste

Aplicar ao APK original `Facebook_573.0.0.37.74.apk`. Não activar ao mesmo tempo
o patch original **Download Facebook Media (573)**.

Testar primeiro a abertura e reprodução de um vídeo sem descarregar. Depois
testar um vídeo normal e um Reel.

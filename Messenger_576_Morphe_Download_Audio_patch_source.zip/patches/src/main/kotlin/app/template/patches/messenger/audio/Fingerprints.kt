package app.template.patches.messenger.audio

import app.morphe.patcher.Fingerprint
import com.android.tools.smali.dexlib2.AccessFlags

/**
 * Messenger 576.0.0.47.92
 *
 * Anchors the existing "Save video" context-menu item.
 * We reuse this plugin for AudioAttachmentData while leaving normal video behaviour intact.
 */
internal val SaveVideoMenuItemFingerprint = Fingerprint(
    accessFlags = listOf(AccessFlags.PUBLIC),
    returnType = "Lcom/facebook/messaging/dialog/MenuDialogItem;",
    parameters = listOf(
        "Landroid/content/Context;",
        "Landroid/os/Parcelable;",
        "Lcom/facebook/messaging/model/messages/Message;",
        "Ljava/lang/String;",
    ),
    strings = listOf("save_video"),
)

package app.template.patches.messenger.audio

import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.PatchException
import app.morphe.patcher.patch.bytecodePatch
import app.template.patches.shared.Constants.MESSENGER_COMPATIBILITY
import app.template.patches.messenger.misc.messengerSignaturePatch

private const val AUDIO_ATTACHMENT =
    "Lcom/facebook/messaging/attachments/AudioAttachmentData;"
private const val MENU_DIALOG_ITEM =
    "Lcom/facebook/messaging/dialog/MenuDialogItem;"
private const val FB_USER_SESSION =
    "Lcom/facebook/auth/usersession/FbUserSession;"
private const val HELPER =
    "Lapp/template/extension/extension/MessengerAudioDownloadHelper;"

// Messenger 576.0.0.47.92:
// LX/7EM; obtains Q51 (audio downloader) from LX/2oy.A00(0x28050).
private const val AUDIO_DOWNLOADER_PROVIDER_ID = 0x28050

/**
 * Adds "Descarregar áudio" to the long-press context menu for Messenger audio messages.
 *
 * Implementation:
 *  - reuses Messenger's existing SaveVideoMenuItem plugin only for AudioAttachmentData;
 *  - calls Messenger's own Q51 audio downloader;
 *  - passes the returned LX/1FU (a FutureTask/ListenableFuture) to the extension;
 *  - the extension copies the resulting Uri to Download/Messenger Audio through MediaStore.
 *
 * Normal Save Video behaviour is untouched.
 *
 * Verified against:
 * com.facebook.orca 576.0.0.47.92
 * arm64-v8a versionCode 345212670
 */
@Suppress("unused")
val messengerDownloadAudioPatch = bytecodePatch(
    name = "Download audio messages",
    description = "Adds a 'Descarregar áudio' action to audio messages and saves them to Downloads.",
) {
    compatibleWith(MESSENGER_COMPATIBILITY)
    dependsOn(messengerSignaturePatch)
    extendWith("extensions/extension.mpe")

    execute {
        val buildMenuMethod = SaveVideoMenuItemFingerprint.method
        val pluginClassType = SaveVideoMenuItemFingerprint.classDef.type
        val pluginClass = mutableClassDefBy(pluginClassType)

        val sessionField = pluginClass.fields
            .singleOrNull { it.type == FB_USER_SESSION }
            ?: throw PatchException(
                "Save-video plugin: FbUserSession field not found in $pluginClassType"
            )

        // DP8(Context, Parcelable, Message, ThreadSummary, Capabilities, Z)Z
        val eligibilityMethod = pluginClass.methods.firstOrNull { method ->
            method.returnType == "Z" &&
                method.parameterTypes.size == 6 &&
                method.parameterTypes[0] == "Landroid/content/Context;" &&
                method.parameterTypes[1] == "Landroid/os/Parcelable;" &&
                method.parameterTypes[2] == "Lcom/facebook/messaging/model/messages/Message;" &&
                method.parameterTypes[3] == "Lcom/facebook/messaging/model/threads/ThreadSummary;" &&
                method.parameterTypes[4] == "Lcom/facebook/xapp/messaging/capability/vector/Capabilities;" &&
                method.parameterTypes[5] == "Z"
        } ?: throw PatchException(
            "Save-video plugin eligibility method not found in $pluginClassType"
        )

        // CTh(Context, View, ..., MenuDialogItem, Message, ..., Z)Z
        val clickMethod = pluginClass.methods.firstOrNull { method ->
            method.returnType == "Z" &&
                method.parameterTypes.size == 10 &&
                method.parameterTypes[0] == "Landroid/content/Context;" &&
                method.parameterTypes[1] == "Landroid/view/View;" &&
                method.parameterTypes[3] == MENU_DIALOG_ITEM &&
                method.parameterTypes[4] == "Lcom/facebook/messaging/model/messages/Message;" &&
                method.parameterTypes.last() == "Z"
        } ?: throw PatchException(
            "Save-video plugin click method not found in $pluginClassType"
        )

        // 1) Make the existing Save Video menu plugin eligible for audio attachments.
        //    p2 = Parcelable attachment.
        eligibilityMethod.addInstructions(
            0,
            """
                instance-of v0, p2, $AUDIO_ATTACHMENT
                if-eqz v0, :morphe_audio_eligibility_original
                const/4 v0, 0x1
                return v0
                :morphe_audio_eligibility_original
                nop
            """.trimIndent(),
        )

        // 2) When the same plugin is building a menu item for AudioAttachmentData,
        //    replace the resource-based title "Save video" by a custom CharSequence.
        //
        // Stock ALN layout in 576:
        //   v1 = new LX/Lrp;
        //   ...
        //   const-string ..., "save_video"
        //   iput-object ..., v1, LX/Lrp;->A07
        //   [insert here]
        //   v0 = new MenuDialogItem(v1)
        //
        // MenuDialogItem enforces XOR: either Lrp.A04 (resource title) OR
        // Lrp.A06 (custom CharSequence) must be set, not both.
        val labelInsertIndex = SaveVideoMenuItemFingerprint.stringMatches.first().index + 2
        buildMenuMethod.addInstructions(
            labelInsertIndex,
            """
                instance-of v0, p2, $AUDIO_ATTACHMENT
                if-eqz v0, :morphe_audio_label_done
                const-string v0, "Descarregar áudio"
                iput-object v0, v1, LX/Lrp;->A06:Ljava/lang/CharSequence;
                const/4 v0, 0x0
                iput v0, v1, LX/Lrp;->A04:I
                :morphe_audio_label_done
                nop
            """.trimIndent(),
        )

        // 3) Intercept the click only when MenuDialogItem.A05 contains AudioAttachmentData.
        //
        // CTh has 23 registers / 11 incoming registers in Messenger 576, so p4 maps
        // above v15. iget-object uses a 4-bit object register and cannot address p4
        // directly; first move it to low local v6 with move-object/from16.
        //
        // Q51 is Messenger's native audio downloader.
        // Q51.A01(session, new Ahr(true, uri)) returns LX/1FU.
        // LX/1FU extends java.util.concurrent.FutureTask, so the extension can
        // handle it as java.util.concurrent.Future<?> without importing Facebook classes.
        clickMethod.addInstructions(
            0,
            """
                move-object/from16 v6, p4
                iget-object v0, v6, $MENU_DIALOG_ITEM->A05:Landroid/os/Parcelable;
                instance-of v1, v0, $AUDIO_ATTACHMENT
                if-eqz v1, :morphe_audio_click_original

                check-cast v0, $AUDIO_ATTACHMENT
                iget-object v1, v0, $AUDIO_ATTACHMENT->A01:Landroid/net/Uri;
                if-eqz v1, :morphe_audio_missing_uri

                const v2, $AUDIO_DOWNLOADER_PROVIDER_ID
                invoke-static {v2}, LX/2oy;->A00(I)LX/2oz;
                move-result-object v2
                invoke-static {v2}, LX/2oz;->A0B(LX/2oz;)Ljava/lang/Object;
                move-result-object v2
                check-cast v2, LX/Q51;

                const/4 v3, 0x1
                new-instance v4, LX/Ahr;
                invoke-direct {v4, v3, v1}, LX/Ahr;-><init>(ZLandroid/net/Uri;)V

                iget-object v5, p0, $pluginClassType->${sessionField.name}:$FB_USER_SESSION
                invoke-virtual {v2, v5, v4}, LX/Q51;->A01($FB_USER_SESSION;LX/Ahr;)LX/1FU;
                move-result-object v2

                invoke-static {p1, v2}, $HELPER->saveFuture(Landroid/content/Context;Ljava/lang/Object;)V
                const/4 v0, 0x1
                return v0

                :morphe_audio_missing_uri
                invoke-static {p1}, $HELPER->showMissingAudio(Landroid/content/Context;)V
                const/4 v0, 0x1
                return v0

                :morphe_audio_click_original
                nop
            """.trimIndent(),
        )
    }
}

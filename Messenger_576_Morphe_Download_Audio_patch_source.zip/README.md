# Messenger 576 — Download audio messages (Morphe)

Target verified during static analysis:

- Package: `com.facebook.orca`
- Version: `576.0.0.47.92`
- ARM64 versionCode: `345212670`
- APK analysed: `com.facebook.orca_576.0.0.47.92-345212670_minAPI28(arm64-v8a)(213240dpi)_apkmirror.com.apk`

## Intended behaviour

Long-press an audio/voice message. The existing Save Video context-menu plugin is reused only for `AudioAttachmentData`, where its label becomes:

`Descarregar áudio`

Tapping it:

1. obtains `AudioAttachmentData.A01` (`android.net.Uri`);
2. obtains Messenger's native `LX/Q51` audio downloader through provider `LX/2oy.A00(0x28050)`;
3. calls `Q51.A01(FbUserSession, new Ahr(true, uri))`;
4. sends the returned `LX/1FU` to `MessengerAudioDownloadHelper`;
5. the helper waits off the UI thread for the resulting `Uri`;
6. copies the audio into `Download/Messenger Audio` through `MediaStore`.

The normal Save Video behaviour is left unchanged.

## Files to add to morphe-patches

Copy these files into the corresponding paths in the `rushiranpise/morphe-patches` source tree:

- `patches/src/main/kotlin/app/template/patches/messenger/audio/Fingerprints.kt`
- `patches/src/main/kotlin/app/template/patches/messenger/audio/DownloadAudioPatch.kt`
- `extensions/extension/src/main/java/app/template/extension/extension/MessengerAudioDownloadHelper.java`

The patch calls:

- `dependsOn(messengerSignaturePatch)`
- `extendWith("extensions/extension.mpe")`

so the standard extension bundle must be rebuilt together with the patch bundle.

## Static-analysis anchors found in the APK

- `LX/Q51;->A01(FbUserSession, LX/Ahr;)LX/1FU;` — native audio download/prefetch API.
- `LX/1FU;` extends `java.util.concurrent.FutureTask` and implements `ListenableFuture`.
- `AudioAttachmentData->A01:Landroid/net/Uri;` — source audio URI.
- `LX/MZa;` — Save Video context-menu plugin.
- `LX/MZa;->DP8(...)Z` — eligibility.
- `LX/MZa;->ALN(...)MenuDialogItem` — menu item builder, string anchor `"save_video"`.
- `LX/MZa;->CTh(...)Z` — click handler.
- `LX/Lrp;->A06:CharSequence` — custom menu title.
- `LX/Lrp;->A04:I` — resource title; must be cleared when `A06` is set.
- `LX/7EM;->A04:LX/2oz;` obtains `Q51` from `LX/2oy.A00(0x28050)` in this exact Messenger build.

## Status

This is a source-level experimental patch derived from the exact APK's DEX bytecode. The control flow and descriptors have been checked statically. It still needs the final Morphe build/apply step and a device test before being considered confirmed working.
